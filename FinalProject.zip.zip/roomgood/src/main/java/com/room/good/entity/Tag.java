package com.room.good.entity;

public enum Tag {
    A,B,C;

}