package com.room.good.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}