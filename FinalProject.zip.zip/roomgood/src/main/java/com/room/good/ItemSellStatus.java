package com.room.good;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}