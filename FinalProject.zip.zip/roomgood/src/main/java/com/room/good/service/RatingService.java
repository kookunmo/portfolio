//package com.room.good.service;
//
//import com.room.good.dto.RatingSummaryDTO;
//
//
//public interface RatingService {
//    RatingSummaryDTO getRatingSummaryByProductPno(Long pno);
//}