package com.room.good.entity;

public enum ClubMemberRole {

    USER,MANAGER,ADMIN,VIP,VVIP
}
