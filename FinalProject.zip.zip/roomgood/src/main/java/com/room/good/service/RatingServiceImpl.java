//package com.room.good.service;
//
//import com.room.good.dto.RatingSummaryDTO;
//import com.room.good.repository.RatingRepository;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.log4j.Log4j2;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//@Service
//@RequiredArgsConstructor
//@Log4j2
//public class RatingServiceImpl {
//    private final RatingRepository ratingRepository;
//
//    public RatingSummaryDTO getRatingSummaryByProductPno(Long pno) {
//        return ratingRepository.findRatingSummaryByProductPno(pno);
//    }
//}
