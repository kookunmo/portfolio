package com.room.good.repository;

import com.room.good.entity.TimeSale;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TimeSaleRepository extends JpaRepository<TimeSale,Long> {
}
