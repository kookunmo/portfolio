package com.room.good;

public enum OrderStatus {
    ORDER, CANCEL
}