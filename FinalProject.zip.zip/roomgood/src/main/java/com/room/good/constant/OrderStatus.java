package com.room.good.constant;

public enum OrderStatus {
    ORDER, CANCEL
}